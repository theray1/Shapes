package projetPOO;


import java.awt.Point;
/**
 * this interface adds the nextPoint method
 * @author theray1
 *
 */
public interface Path {
	public abstract Point nextPoint();
}
