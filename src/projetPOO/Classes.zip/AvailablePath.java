package projetPOO;

	/**
	 * This enumeration is a list of all available paths in this project 
	 * @author theray1
	 *
	 */
public enum AvailablePath {
	circle,
	spiral,
	lemniscate
}
