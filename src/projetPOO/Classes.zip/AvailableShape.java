package projetPOO;

	/**
	 * This enumeration is a list of all available shapes in this project 
	 * @author theray1
	 *
 	*/

public enum AvailableShape {
	circle,
	square
}
